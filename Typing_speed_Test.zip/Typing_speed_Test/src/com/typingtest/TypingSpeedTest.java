// Main class - starts the test
package com.typingtest;

import java.util.Scanner;

public class TypingSpeedTest {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        boolean continueTesting = true;

        while (continueTesting) {
            System.out.println("Welcome to the Typing Speed Test!\n");

            // Display a random sentence
            String sentenceToType = SentenceManager.displayRandomSentence();

            // Capture user input and calculate results
            InputHandler.getUserInputAndCalculateTime(sentenceToType);

            // Ask user if they want to restart or exit
            continueTesting = Utility.askToRestart(scanner);
        }
        System.out.println("Thank you for using the Typing Speed Test. Goodbye!");
    }
}
