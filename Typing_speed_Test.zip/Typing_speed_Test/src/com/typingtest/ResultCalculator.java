// Calculates accuracy and WPM
package com.typingtest;

public class ResultCalculator {
    public static double calculateAccuracy(String original, String userInput) {
        int correctChars = 0;
        int minLength = Math.min(original.length(), userInput.length());

        // Compare character by character
        for (int i = 0; i < minLength; i++) {
            if (original.charAt(i) == userInput.charAt(i)) {
                correctChars++;
            }
        }

        // Calculate accuracy percentage
        int totalChars = original.length();
        return ((double) correctChars / totalChars) * 100;
    }
}
