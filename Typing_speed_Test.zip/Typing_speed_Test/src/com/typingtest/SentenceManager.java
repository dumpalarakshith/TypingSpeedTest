// Manages sentence display
package com.typingtest;

import java.util.Random;
import java.util.HashSet;
import java.util.Set;

public class SentenceManager {
    private static final String[] sentences = {
            "Code is like humor. When you have to explain it, it's bad.",
            "Simplicity is the soul of efficiency.",
            "Java makes the world go round.",
            "Typing fast requires consistent practice.",
            "Success begins with small efforts.",
            "A goal without a plan is just a wish.",
            "Time and tide wait for none.",
            "Hard work beats talent when talent doesn't work hard.",
            "Believe in yourself and all that you are.",
            "Consistency is the key to mastery.",
            "Perseverance is not a long race.",
            "Every accomplishment starts with a decision.",
            "Mistakes are proof that you are trying.",
            "Stay curious and keep learning.",
            "Dream big, work hard, stay focused."
    };

    private static final Set<Integer> recentIndexes = new HashSet<>();
    private static final int MAX_RECENT = 2;  // Avoid last 2 sentences

    public static String displayRandomSentence() {
        Random random = new Random();
        int randomIndex;

        // Keep generating a new index until it's not a recent sentence
        do {
            randomIndex = random.nextInt(sentences.length);
        } while (recentIndexes.contains(randomIndex));

        // Add the new index to recentIndexes
        recentIndexes.add(randomIndex);

        // Remove the oldest entry if size exceeds MAX_RECENT
        if (recentIndexes.size() > MAX_RECENT) {
            recentIndexes.remove(recentIndexes.iterator().next());
        }

        // Display the selected sentence
        System.out.println("Type the following sentence:");
        System.out.println(sentences[randomIndex]);
        return sentences[randomIndex];
    }
}

