// Handles input and timing
package com.typingtest;

import java.util.Scanner;
import java.util.concurrent.TimeUnit;

public class InputHandler {
    public static void getUserInputAndCalculateTime(String sentenceToType) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("\nStart typing when you're ready:");

        // Start time before user starts typing
        long startTime = System.nanoTime();

        // Read user input
        String userInput = scanner.nextLine();

        // Validate input
        if (userInput.isEmpty()) {
            System.out.println("Invalid input! You didn't type anything. Please try again.");
            return;
        }

        if (!userInput.matches("^[a-zA-Z.,'\"!?\\s]*$")) {
            System.out.println("Invalid input! Please type only valid English characters and punctuation.");
            return;
        }

        // End time after typing is complete
        long endTime = System.nanoTime();

        // Calculate duration in seconds
        long durationInSeconds = Math.max(1, TimeUnit.NANOSECONDS.toSeconds(endTime - startTime));

        // Calculate results
        int wordCount = sentenceToType.split(" ").length;
        double wordsPerMinute = (wordCount * 60.0) / durationInSeconds;
        double accuracy = ResultCalculator.calculateAccuracy(sentenceToType, userInput);

        // Display results
        System.out.println("\n--- Results ---");
        if (userInput.equals(sentenceToType)) {
            System.out.println("Great job! You typed the sentence correctly.");
        } else {
            System.out.println("Oops! Your input didn't match the sentence.");
        }

        System.out.println("Time taken: " + durationInSeconds + " seconds.");
        System.out.printf("Your typing speed: %.2f WPM.\n", wordsPerMinute);
        System.out.printf("Accuracy: %.2f%%\n", accuracy);
    }
}
