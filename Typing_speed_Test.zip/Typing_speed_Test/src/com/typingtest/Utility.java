// Restart logic and utility methods
package com.typingtest;

import java.util.Scanner;

public class Utility {
    public static boolean askToRestart(Scanner scanner) {
        while (true) {
            System.out.print("\nDo you want to try again? (Y/N): ");
            String choice = scanner.nextLine().trim().toUpperCase();

            if (choice.equals("Y")) {
                return true;
            } else if (choice.equals("N")) {
                return false;
            } else {
                System.out.println("Invalid choice. Please enter Y or N.");
            }
        }
    }
}
